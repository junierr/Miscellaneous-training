# K-Nearest Neighbor Classification
from sklearn.model_selection import train_test_split
from sklearn.metrics import classification_report
from sklearn import datasets
from sklearn.metrics import accuracy_score
import numpy as np
import operator

def classify0(inX,dataSet,labels,k):
    dataSetSize=dataSet.shape[0]
    #距离计算，新的数据与样本的距离进行减法
    diffMat = np.tile(inX, (dataSetSize,1)) - dataSet
    #对数组的每一项进行平方
    sqDiffMat=diffMat**2
    #数组每个特征值进行求和
    sqDistances=sqDiffMat.sum(axis=1)
    #每个值开方
    distances=sqDistances**0.5
    #索引值排序
    sortedDistIndicies = distances.argsort()
    #选取距离最小的前k个值进行索引，从k个中选取分类最多的一个作为新数据的分类
    classCount={}
    for i in range(k):
        voteIlabel=labels[sortedDistIndicies[i]]
        classCount[voteIlabel]=classCount.get(voteIlabel,0)+1
    sortedClassCount=sorted(classCount.items(),
    key=operator.itemgetter(1),reverse=True)
    #返回前k个点中频率最高的类别
    return sortedClassCount[0][0]

# load the MNIST digits dataset
mnist = datasets.load_digits()

#print (mnist.data)

# Training and testing split,
# 75% for training and 25% for testing
(trainData, testData, trainLabels, testLabels) = train_test_split(np.array(mnist.data), mnist.target, test_size=0.25, random_state=42)

# take 10% of the training data and use that for validation
(trainData, valData, trainLabels, valLabels) = train_test_split(trainData, trainLabels, test_size=0.1, random_state=84)

# Checking sizes of each data split
print("training data points: {}".format(len(trainLabels)))
print("validation data points: {}".format(len(valLabels)))
print("testing data points: {}".format(len(testLabels)))


# initialize the values of k for our k-Nearest Neighbor classifier along with the
# list of accuracies for each value of k
kVals = range(1, 30, 2)
accuracies = []


# loop over kVals
for k in range(1, 30, 2):
    y_hat=[]
    for inX in valData:
           y_hat.append(classify0(inX,trainData,trainLabels,k))
    #accuracy, y_hat = clf.fit(trainData, trainLabels, valData, valLabels)
    accuracy = accuracy_score(valLabels, y_hat)
    print("k=%d, accuracy=%.2f%%" % (k, accuracy * 100))
    accuracies.append(accuracy)

# largest accuracy
# np.argmax returns the indices of the maximum values along an axis
t = np.argmax(accuracies)
print("k=%d achieved highest accuracy of %.2f%% on validation data" % (kVals[t],
    accuracies[t] * 100))


# Now that I know the best value of k, re-train the classifier
y_hat=[]
for inX in testData:
        y_hat.append(classify0(inX,trainData,trainLabels,kVals[t]))
#accuracy, y_hat = clf.fit(trainData, trainLabels, valData, valLabels)
accuracy = accuracy_score(testLabels, y_hat)
#clf = Knn(kVals[t])
#accuracy, y_hat = clf.fit(trainData,trainLabels,testData,testLabels)
print(accuracy)

# Evaluate performance of model for each of the digits
print("EVALUATION ON TESTING DATA")
print(classification_report(testLabels, y_hat))

